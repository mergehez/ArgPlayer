package com.arges.sepan.argmusicplayer;

import android.content.Context;
import android.util.AttributeSet;


public class ArgPlayerSmallViewRoot extends ArgPlayerView {
    public ArgPlayerSmallViewRoot(Context context) {
        super(context);
    }
    public ArgPlayerSmallViewRoot(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
    public ArgPlayerSmallViewRoot(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void init(Context context, int layoutResId) {
        super.init(context,layoutResId);
    }
}
