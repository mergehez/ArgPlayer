package com.arges.sepan.argmusicplayer.Enums;

public enum AudioState{
    NO_ACTION,
    PLAYING,
    PAUSED,
    PAUSE_CMD,
    STOPPED
}