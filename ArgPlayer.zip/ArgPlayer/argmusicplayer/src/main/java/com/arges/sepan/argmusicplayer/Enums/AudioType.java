package com.arges.sepan.argmusicplayer.Enums;

public enum AudioType {
    URL,
    RAW,
    ASSETS,
    FILE_PATH
}
