package com.arges.sepan.argmusicplayer.Enums;

public enum ErrorType {
    INVALID_AUDIO,
    NO_AUDIO_SETTED,
    EMPTY_PLAYLIST,
    MEDIAPLAYER_ERROR,
    MEDIAPLAYER_TIMEOUT
}
